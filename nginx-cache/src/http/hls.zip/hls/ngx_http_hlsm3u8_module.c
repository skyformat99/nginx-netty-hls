/*
* Copyright (C) migu wanghuan
*/

#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>
#include <ngx_md5.h>
#include <ngx_time.h>
#include <json-c/json.h>

#define URI_NAME_MAXLEN 1024

typedef struct 
{
	ngx_str_t ts_path;
	ngx_flag_t authentication;
	ngx_str_t check_sum_key;
} ngx_http_hlsm3u8_loc_conf_t;

static void *ngx_http_hlsm3u8_create_loc_conf(ngx_conf_t *cf);
static char *ngx_http_hlsm3u8_merge_loc_conf(ngx_conf_t *cf, void *parent, void *child);
static ngx_int_t hlsm3u8_playseek_subrequest_cb(ngx_http_request_t *request,void *data,ngx_int_t rc);
static ngx_int_t ngx_http_hlsm3u8_handler(ngx_http_request_t *r);
static char *ngx_http_hlsm3u8_register(ngx_conf_t *cf, ngx_command_t *cmd, void *conf);
static char *ngx_http_get_tspath(ngx_conf_t *cf, ngx_command_t *cmd, void *conf);
static void Traversal(ngx_chain_t *chain);

static ngx_http_module_t  ngx_http_hlsm3u8_module_ctx = 
{
	NULL,                          		/* preconfiguration */
	NULL,    				/* postconfiguration */
	NULL,					/* create main configuration */
	NULL,                          		/* init main configuration */
	NULL,                          		/* create server configuration */
	NULL,                          		/* merge server configuration */
	ngx_http_hlsm3u8_create_loc_conf,	/* create location configration */
	ngx_http_hlsm3u8_merge_loc_conf		/* merge location configuration */
};

static char *ngx_http_get_checksum_key_profile(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
	ngx_conf_set_str_slot(cf, cmd, conf);

	return NGX_CONF_OK;
}

static ngx_command_t ngx_http_hlsm3u8_commands[] = 
{ 
	{ 
		ngx_string("hlsm3u8"),
		NGX_HTTP_LOC_CONF|NGX_CONF_NOARGS,
		ngx_http_hlsm3u8_register,
		NGX_HTTP_LOC_CONF_OFFSET,
		0,
		NULL
	},

	{
		ngx_string("tspath"),
		NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
		ngx_http_get_tspath,
		NGX_HTTP_LOC_CONF_OFFSET,
		offsetof(ngx_http_hlsm3u8_loc_conf_t, ts_path),
		NULL
	},

	{ 
		ngx_string("auth"),
		NGX_HTTP_LOC_CONF|NGX_CONF_FLAG,
		ngx_conf_set_flag_slot,//��������ָ�����ģ��conf�ṹ�ĳ�Ա����
		NGX_HTTP_LOC_CONF_OFFSET,
		offsetof(ngx_http_hlsm3u8_loc_conf_t, authentication),
		NULL
	},

	{
		ngx_string("encryptkey"),
		NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
		ngx_http_get_checksum_key_profile,//��������ָ�����ģ��conf�ṹ�ĳ�Ա����
		NGX_HTTP_LOC_CONF_OFFSET,
		offsetof(ngx_http_hlsm3u8_loc_conf_t, check_sum_key),
		NULL
	},


	ngx_null_command
}; 

ngx_module_t  ngx_http_hlsm3u8_module = 
{
	NGX_MODULE_V1,
	&ngx_http_hlsm3u8_module_ctx,  /* module context 	*/
	ngx_http_hlsm3u8_commands,     /* module directives */
	NGX_HTTP_MODULE,               /* module type 		*/
	NULL,                          /* init master 		*/
	NULL,                          /* init module 		*/
	NULL,						   /* init process 		*/
	NULL,                          /* init thread 		*/
	NULL,                          /* exit thread 		*/
	NULL,                          /* exit process 		*/
	NULL,                          /* exit master 		*/
	NGX_MODULE_V1_PADDING
};


static char *ngx_http_hlsm3u8_register(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
	ngx_http_core_loc_conf_t  *clcf;
	//ngx_http_hlsm3u8_loc_conf_t * lc = conf;
	clcf = ngx_http_conf_get_module_loc_conf(cf, ngx_http_core_module);
	//lc = ngx_http_conf_get_module_loc_conf(cf, ngx_http_hlsm3u8_module);

	clcf->handler = ngx_http_hlsm3u8_handler;

	return NGX_CONF_OK;
}

static char *ngx_http_get_tspath(ngx_conf_t *cf, ngx_command_t *cmd, void *conf)
{
	ngx_conf_set_str_slot(cf, cmd, conf);

	return NGX_CONF_OK;	
}

static void *ngx_http_hlsm3u8_create_loc_conf(ngx_conf_t *cf) 
{ 
	ngx_http_hlsm3u8_loc_conf_t *conf; 
	conf = ngx_pcalloc(cf->pool, sizeof(ngx_http_hlsm3u8_loc_conf_t)); 
	
	if (conf == NULL)
		return NGX_CONF_ERROR; 

	conf->authentication = NGX_CONF_UNSET;

	conf->ts_path.data = NULL;
	conf->ts_path.len = 0;

	return conf; 
}

static char *ngx_http_hlsm3u8_merge_loc_conf(ngx_conf_t *cf, void *parent, void *child) 
{ 
	ngx_http_hlsm3u8_loc_conf_t *prev = parent; //server��loc����	
	ngx_http_hlsm3u8_loc_conf_t *conf = child; // �Լ���loca����	
	ngx_conf_merge_value(conf->authentication, prev->authentication, 0);
	ngx_conf_merge_str_value(conf->ts_path, prev->ts_path, "");

	if(conf->authentication == 1)
	{
	}

	return NGX_CONF_OK; 
}

static ngx_int_t hlsm3u8_review_subrequest_cb(ngx_http_request_t *request, void *data, ngx_int_t rc)
{	
	printf("hlsm3u8_review_callback\n");
	ngx_int_t head_len = 0;

	ngx_buf_t *p = &request->upstream->buffer;
	printf("upstream->buffer = %s\n", p->pos);
	printf("response code = %d\n", (int)request->upstream->state->status);	
	ngx_http_request_t *parent = request->parent;

	struct json_object *obj_res = NULL;
	struct json_object *json = json_tokener_parse((char*)p->pos);

	json_object_object_get_ex(json, "ErrCode", &obj_res);

	int error_code = json_object_get_int(obj_res);
	printf("error_code = %d\n", error_code);

	if(200 != error_code)
	{
		return error_code;
	}

	ngx_buf_t *buff = ngx_pcalloc(parent->pool, sizeof(ngx_buf_t));
	if(NULL == buff)
	{
		return NGX_HTTP_INTERNAL_SERVER_ERROR;
	}

	u_char *declare = ngx_pcalloc(parent->pool, 64);
	if(NULL == declare)
	{
		return NGX_HTTP_INTERNAL_SERVER_ERROR;
	}

	u_char *end = ngx_snprintf(declare, 64, "%s\n%s:%d\n%s:%d\n", "#EXTM3U", "#EXT-X-VERSION", 3, "#EXT-X-TARGETDURATION", 8);

	head_len += end - declare;

	//printf("declare = \n%s\n", declare);

	buff->memory = 1;
	//buff->in_file = 0;
	buff->start = declare;
	buff->end = end;
	buff->pos = buff->start;
	buff->last = buff->end;

	ngx_chain_t *chain_head = ngx_pcalloc(parent->pool, sizeof(ngx_chain_t));
	ngx_chain_t *chain_end = NULL;

	if(NULL == chain_head)
	{
		return NGX_HTTP_INTERNAL_SERVER_ERROR; 
	}

	chain_head->buf = buff;
	chain_head->next = NULL;

	chain_end = chain_head;

	json_object_object_get_ex(json, "Ts_path", &obj_res);
	int i;
	for(i = 0; i < json_object_array_length(obj_res); i++)
	{
		struct json_object *obj = json_object_array_get_idx(obj_res, i);

		u_char *ts_content = ngx_pcalloc(parent->pool, URI_NAME_MAXLEN);
		if(NULL == ts_content)
		{
			return NGX_HTTP_INTERNAL_SERVER_ERROR; 
		}

		u_char *end = ngx_snprintf(ts_content, URI_NAME_MAXLEN, "%s:%f,\n%s?%V\n", "#EXTINF", 10.0, json_object_get_string(obj), &parent->args);

		head_len += end - ts_content;

		//printf("[%d]=\n%s\n", i, ts_content);

		ngx_buf_t *buff = ngx_pcalloc(parent->pool, sizeof(ngx_buf_t));

		buff->memory = 1;
		//buff->in_file = 0;
		buff->start = ts_content;
		buff->end = end;
		buff->pos = buff->start;
		buff->last = buff->end;

		ngx_chain_t *chain = ngx_pcalloc(parent->pool, sizeof(ngx_chain_t));

		if(NULL == chain)
		{
			return NGX_HTTP_INTERNAL_SERVER_ERROR; 
		}

		chain->buf = buff;
		chain->next = NULL;

		chain_end->next = chain;
		chain_end = chain;
	}

	u_char *end_list = ngx_pcalloc(parent->pool, 20);
	u_char *end_p = ngx_snprintf(end_list, 20, "%s", "#EXT-X-ENDLIST");
	//printf("end_list = %s\n", (char*)end_list);

	ngx_buf_t *endlist_buff = ngx_pcalloc(parent->pool, sizeof(ngx_buf_t));

	endlist_buff->memory = 1;
	endlist_buff->start = end_list;
	endlist_buff->end = end_p;
	endlist_buff->pos = endlist_buff->start;
	endlist_buff->last = endlist_buff->end;
	head_len += end_p - end_list;

	ngx_chain_t *last_chain = ngx_pcalloc(parent->pool, sizeof(ngx_chain_t));

	last_chain->buf = endlist_buff;
	last_chain->next = NULL;

	chain_end->next = last_chain;
	chain_end = last_chain;

	chain_end->buf->last_in_chain = 1;
	chain_end->buf->last_buf = 1;
	chain_end->buf->flush = 1;

	parent->out = NULL;

	parent->headers_out.status = NGX_HTTP_OK;
	ngx_str_set(&parent->headers_out.content_type,"application/octet-stream");
	parent->root_tested = !parent->error_page;
	parent->allow_ranges = 1;
	parent->headers_out.content_length_n = head_len;

	printf("head len = %d\n", (int)head_len);

	ngx_int_t res = ngx_http_send_header(parent);

	if(res == NGX_ERROR || res > NGX_OK || parent->header_only)
	{
		return res;
	}

	Traversal(chain_head);
	
	return ngx_http_output_filter(parent, chain_head);
}

static void Traversal(ngx_chain_t *chain) {

	ngx_chain_t *tmp = chain;
        while(tmp != NULL)
        {
              char a[1024] = {0};
              memcpy(a, tmp->buf->start, tmp->buf->end - tmp->buf->start);
              printf("%s", a);
              tmp = tmp->next;
        }
}

typedef enum QueryType_
{
	QUERY_TYPE_DERECT,
	QUERY_TYPE_REVIEW,
	QUERY_TYPE_TIMESEEK,
	QUERY_TYPE_NONE,
}QueryType;

static void hlsm3u8_post_handler(ngx_http_request_t *r)
{
	printf("hlsm3u8_post_handler status = %d\n", (int)r->headers_out.status);

	
	ngx_str_set(&r->headers_out.content_type,"application/octet-stream");
        r->headers_out.status = NGX_HTTP_OK;  
	r->allow_ranges = 1;
	r->headers_out.content_length_n = 0;

	printf("000000000000000000000\n");

	if (r->headers_out.status != NGX_HTTP_OK)
    	{
		ngx_http_send_header(r);

    		ngx_http_finalize_request(r, 404);
        	
		return;
    	}
	
	ngx_http_send_header(r);
	ngx_http_finalize_request(r, 404);
}

static ngx_int_t hlsm3u8_playseek_subrequest_cb(ngx_http_request_t *request, void *data, ngx_int_t rc)
{
	printf("m3u8_subrequest_cb\n");

	ngx_http_request_t *parent = request->parent;

	if(request->headers_out.status == NGX_HTTP_OK)
    	{
        
    	

	printf("headers_out.status = %d\n", (int)request->headers_out.status);
	ngx_buf_t *p = &request->upstream->buffer;
	printf("buff = %s\n",(char *)p->pos);
	if(NULL == p->pos) {

		printf("hlsm3u8_playseek_subrequest_cb error\n");

		return NGX_ERROR;
	}

	int buf_size = 0;

	request->parent->out = NULL;
	ngx_buf_t *pbuf = NULL;
	ngx_chain_t *cp = NULL;
	struct json_object *json = json_tokener_parse((char *)p->pos);
	
	struct json_object *obj_res = NULL;
	json_object_object_get_ex(json, "ErrCode", &obj_res);

        int error_code = json_object_get_int(obj_res);
        printf("error_code = %d\n", error_code);

	struct json_object *test_object;
	json_object_object_get_ex(json, "M3u8_content", &test_object);
	const char *test = json_object_get_string(test_object);
	printf("m3u8_content = %s\n", test);

        if(200 != error_code)
        {
                goto NOT_FOUND;
        }

	struct json_object *result_object;
	json_object_object_get_ex(json,"M3u8_content", &result_object);
	struct json_object *obj_content_len;
	json_object_object_get_ex(json,"Content_len", &obj_content_len);
	const char *tmp = json_object_get_string(result_object);
	buf_size = json_object_get_int(obj_content_len);
	//buf_size = strlen(tmp);

	printf("------------buff len = %d\n", buf_size);

	pbuf = ngx_pcalloc(request->parent->pool,sizeof(ngx_buf_t));
	if(pbuf==NULL)
	{
		return NGX_HTTP_INTERNAL_SERVER_ERROR;
	}     
	cp = ngx_pcalloc(request->parent->pool,sizeof(ngx_chain_t));
	if(cp==NULL)
	{
		return NGX_HTTP_INTERNAL_SERVER_ERROR;
	}
	char *p_tmp_out = ngx_pcalloc(request->parent->pool, buf_size);
	if(p_tmp_out==NULL)
	{
		return NGX_HTTP_INTERNAL_SERVER_ERROR;
	}
	//printf("tmp = %s\n", tmp);
	memcpy(p_tmp_out, tmp, buf_size);
	pbuf->memory = 1;
	pbuf->start = (u_char *)p_tmp_out;
	pbuf->end = ((u_char *)p_tmp_out) + buf_size;
	pbuf->pos = pbuf->start;
	pbuf->last = pbuf->end;

	cp->buf = pbuf;
	cp->next = NULL;
	cp->buf->last_in_chain = 1;
	cp->buf->flush = 1;

NOT_FOUND:
	request->parent->headers_out.status = NGX_HTTP_OK;
	ngx_str_set(&request->parent->headers_out.content_type,"application/octet-stream");
	request->parent->root_tested = !request->parent->error_page;
	request->parent->allow_ranges = 1;
	request->parent->headers_out.content_length_n = buf_size;
	ngx_int_t result;
	result = ngx_http_send_header(request->parent);
	if(result == NGX_ERROR || result > NGX_OK || request->parent->header_only)
	{
		printf("send header error\n");
		return result;
	}  

	result = ngx_http_output_filter(request->parent, cp);

	}

	parent->write_event_handler = hlsm3u8_post_handler;

	return NGX_OK;
}

static ngx_int_t ngx_http_hlsm3u8_handler(ngx_http_request_t *r)
{
	u_char *p = NULL;
	ngx_http_hlsm3u8_loc_conf_t *local_conf = NULL;
	ngx_http_post_subrequest_t *psr = NULL;
	ngx_str_t review_start;
        ngx_str_t review_end;
        ngx_str_t seek_time;
	ngx_str_t query = ngx_string("/upstream");
        ngx_str_t argus;
	ngx_http_request_t *sr = NULL;
	ngx_int_t rc = 0;

	printf("ngx_http_hlsm3u8_handler\n");

	if(!(r->method & (NGX_HTTP_GET | NGX_HTTP_HEAD)))
	{
		return NGX_HTTP_NOT_ALLOWED;
	}

	if(r->uri.data[r->uri.len - 1] == '/')
	{
		return NGX_DECLINED;
	}

	local_conf = ngx_http_get_module_loc_conf(r, ngx_http_hlsm3u8_module);
	
	if(NULL == local_conf)
	{
		return NGX_HTTP_INTERNAL_SERVER_ERROR;
	}

	r->out = NULL;

	psr = ngx_palloc(r->pool, sizeof(ngx_http_post_subrequest_t));
	
	if(NULL == psr)
	{
		return NGX_HTTP_INTERNAL_SERVER_ERROR;
	}

	if((NGX_OK == ngx_http_arg(r, (u_char *) "playbackbegin", 13, &review_start)) && (NGX_OK == ngx_http_arg(r, (u_char *) "playbackend", 11, &review_end)))
	{
		psr->handler = hlsm3u8_review_subrequest_cb;
	}
	else if(NGX_OK == ngx_http_arg(r, (u_char *) "playseek", 8, &seek_time))
	{
		psr->handler = hlsm3u8_playseek_subrequest_cb;
	}
	else
	{
		return NGX_HTTP_FORBIDDEN;
	}

	argus.data = ngx_palloc(r->pool, URI_NAME_MAXLEN);
	
	if(NULL == argus.data) {

		return NGX_HTTP_INTERNAL_SERVER_ERROR;
	}

	p = ngx_snprintf(argus.data, URI_NAME_MAXLEN, "%V?%V", &r->uri, &r->args);

	argus.len = p - argus.data;
	
	printf("---------argus = %s\n", argus.data);

	rc = ngx_http_subrequest(r, &query, &argus, &sr, psr, NGX_HTTP_SUBREQUEST_IN_MEMORY);

	if(rc != NGX_OK)
	{
		return NGX_HTTP_SERVICE_UNAVAILABLE;
	}    

	return NGX_OK;
}

#if 0
ngx_int_t ngx_hlsm3u8_author(ngx_http_request_t *r, ngx_http_hlsm3u8_loc_conf_t *lc)
{
	//printf("wanghuan - ngx_hlsm3u8_author enter\n");

	ngx_str_t msisdn;
	ngx_str_t mdspid;
	ngx_str_t spid;
	ngx_str_t netType;
	ngx_str_t sid;
	ngx_str_t pid;
	ngx_str_t timestamp;
	ngx_str_t Channel_ID;
	ngx_str_t ProgramID;
	ngx_str_t ParentNodeID;
	ngx_str_t client_ip;
	ngx_str_t assertID;
	ngx_str_t encrypt;
	//ngx_str_t checksumprofile;
	ngx_str_t path;

	//u_char profile[] = "MDN2000";
	//checksumprofile.data = profile;
	//checksumprofile.len = ngx_strlen(profile);

	u_char path_buff[64] = {0};
	ngx_memcpy(path_buff, r->uri_start + 1, r->args_start - r->uri_start - 1);
	path.data = path_buff;
	path.len = ngx_strlen(path.data);

	if(NGX_OK != ngx_http_arg(r, (u_char*)"msisdn", 6, &msisdn))
		return 404;
	if(NGX_OK != ngx_http_arg(r, (u_char*)"mdspid", 6, &mdspid))
		return 404;
	if(NGX_OK != ngx_http_arg(r, (u_char*)"spid", 4, &spid))
		return 404;
	if(NGX_OK != ngx_http_arg(r, (u_char*)"netType", 7, &netType))
		return 404;
	if(NGX_OK != ngx_http_arg(r, (u_char*)"sid", 3, &sid))
		return 404;
	if(NGX_OK != ngx_http_arg(r, (u_char*)"pid", 3, &pid))
		return 404;
	if(NGX_OK != ngx_http_arg(r, (u_char*)"timestamp", 9, &timestamp))
		return 404;
	if(NGX_OK != ngx_http_arg(r, (u_char*)"Channel_ID", 10, &Channel_ID))
		return 404;
	if(NGX_OK != ngx_http_arg(r, (u_char*)"ProgramID", 9, &ProgramID))
		return 404;
	if(NGX_OK != ngx_http_arg(r, (u_char*)"ParentNodeID", 12, &ParentNodeID))
		return 404;
	if(NGX_OK != ngx_http_arg(r, (u_char*)"client_ip", 9, &client_ip))
		return 404;
	if(NGX_OK != ngx_http_arg(r, (u_char*)"assertID", 8, &assertID))
		return 404;
	if(NGX_OK != ngx_http_arg(r, (u_char*)"encrypt", 7, &encrypt))
		return 404;

	u_char check_sum_str[512] = {0};
	ngx_snprintf(check_sum_str, 511, "%Vmsisdn=%V&mdspid=%V&spid=%V&netType=%V&sid=%V&pid=%V&timestamp=%V&Channel_ID=%V&ProgramID=%V&ParentNodeID=%V&client_ip=%V&assertID=%V%V", &path, &msisdn, &mdspid, &spid, &netType, &sid, &pid, &timestamp, &Channel_ID, &ProgramID, &ParentNodeID, &client_ip, &assertID, &(lc->check_sum_key));

	//printf("wanghuan - check_sum_str111 = %s\n", check_sum_str);

	u_char buff[33] = {0};
	ngx_sprintf(buff, "%V", &encrypt);
	//printf("encrypt:   %s\n", buff);

	ngx_md5_t md5;
	u_char final[16];
	ngx_md5_init(&md5);
	ngx_md5_update(&md5, check_sum_str, ngx_strlen(check_sum_str));
	ngx_md5_final(final, &md5);

	u_char final_str[32] = {0};
	int i;
	//int len = 32;
	//ngx_ext_crypto_hex((const unsigned char*)final, 16, (unsigned char*)final_str, (unsigned int *)&len);
	for(i=0; i<16; i++)
	{  
		sprintf((char *)final_str+i*2, "%02x", final[i]);  
	}

	//printf("final_str: %s\n", final_str);

	if(0 == ngx_strncmp(encrypt.data, final_str, 32))
	{
		//printf("---------------wanghuan - check sum succeed!----------------\n");

		return NGX_OK;
	}
	else
	{
		//printf("---------------wanghuan - check sum failed!------------------\n");

		return NGX_HTTP_FORBIDDEN;
	}	
}
#endif
